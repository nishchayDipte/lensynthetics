"""
LendSynthetix — The Loan War Room
Multi-Agent Orchestration for Commercial Lending
Stack: LangGraph + Groq
"""

import os
import re
import time
import operator
from typing import TypedDict, Annotated, List, Optional
from enum import Enum

from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_groq import ChatGroq

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

RAROC_APPROVE       = 0.15
RAROC_ESCALATE      = 0.08
MAX_DEBATE_ROUNDS   = 2   # reduced from 3 — saves ~3 LLM calls on clean cases
MAX_HISTORY_ENTRIES = 20

# ─────────────────────────────────────────────
# LLM FACTORY  (cached per session)
# ─────────────────────────────────────────────

_llm_cache: dict = {}

def get_llm(temperature: float = 0.3, max_tokens: int = 500) -> ChatGroq:
    key = (os.environ.get("LS_MODEL", "llama-3.1-8b-instant"), temperature, max_tokens)
    if key not in _llm_cache:
        _llm_cache[key] = ChatGroq(
            model=key[0],
            api_key=os.environ.get("GROQ_API_KEY", "").strip(),
            temperature=temperature,
            max_tokens=max_tokens,
        )
    return _llm_cache[key]


def _invoke_with_retry(llm: ChatGroq, prompt: str, max_retries: int = 3) -> str:
    """Call LLM with exponential-backoff retry on Groq 429 errors."""
    for attempt in range(max_retries):
        try:
            return llm.invoke(prompt).content
        except Exception as e:
            err = str(e)
            if "429" in err or "rate_limit" in err.lower():
                wait = 10 * (attempt + 1)
                print(f"[WAR_ROOM] Rate limited — waiting {wait}s (attempt {attempt+1}/{max_retries})")
                time.sleep(wait)
            else:
                raise
    raise RuntimeError("Groq API rate limit exceeded after retries. Please wait and try again.")


# ─────────────────────────────────────────────
# STATE
# ─────────────────────────────────────────────

class LoanDecision(str, Enum):
    PENDING   = "PENDING"
    APPROVED  = "APPROVED"
    REJECTED  = "REJECTED"
    ESCALATED = "ESCALATED"


class WarRoomState(TypedDict):
    loan_application:  str
    company_name:      str
    sales_memo:        str
    risk_memo:         str
    compliance_memo:   str
    financial_metrics: str          # structured block extracted by risk agent
    debate_history:    Annotated[List[str], operator.add]
    debate_round:      int
    max_rounds:        int
    compliance_veto:   bool
    veto_enabled:      bool
    critical_flags:    List[str]
    resolved_flags:    List[str]
    raroc_score:       Optional[float]
    raroc_formula:     str
    final_decision:    LoanDecision
    decision_memo:     str
    consensus_rounds:  int
    flags_resolved:    int
    _sales_weight:     int          # stored by moderator for analytics
    _risk_weight:      int          # stored by moderator for analytics


# ─────────────────────────────────────────────
# AGENT PROMPTS
# ─────────────────────────────────────────────

SALES_AGENT_PROMPT = """You are the Relationship Manager (Sales Agent) at a commercial bank in India.
Advocate for loan approval based on genuine strengths. Be concise and specific.

RESPONSE FORMAT (use these exact headers):
MEMO TYPE: INITIAL REVIEW
POSITION: APPROVE / CONDITIONAL APPROVE / NEUTRAL
KEY ARGUMENTS:
• [specific argument with data point from the application]
• [specific argument with data point from the application]
• [specific argument with data point from the application]
PROPOSED CONDITIONS: [concrete conditions or "None"]
RESPONSE TO FLAGS: [address each flag specifically, or "No flags yet"]"""


RISK_AGENT_PROMPT = """You are the Credit Underwriter (Risk Agent) at a commercial bank in India.
Protect the bank's capital with rigorous data-driven analysis. Be concise and specific.

RESPONSE FORMAT (use these exact headers):
MEMO TYPE: INITIAL REVIEW
POSITION: APPROVE / REJECT / CONDITIONAL
RISK SCORE: [1-10]

FINANCIAL METRICS EXTRACTED:
- DSCR: [value or "Not stated"]
- Debt-to-Equity Ratio: [value or "Not stated"]
- Annual Revenue: [value or "Not stated"]
- Net Income: [value or "Not stated"]
- Loan Amount: [value or "Not stated"]
- Collateral Value: [value or "Not stated"]
- Credit/CIBIL Score: [value or "Not stated" — check entire text including COMPLIANCE/AML section]
- Revenue Growth YoY: [value or "Not stated"]

KEY CONCERNS:
• [concern with specific metric value]
• [concern with specific metric value]
FLAGS RAISED: [comma-separated flag names or "None"]
MITIGANTS ACKNOWLEDGED: [valid Sales arguments, or "None"]"""


COMPLIANCE_AGENT_PROMPT = """You are the Compliance Officer at a commercial bank in India.
Enforce KYC, AML, and RBI guidelines. You hold VETO POWER over all other agents.
Issue veto ONLY for confirmed regulatory violations:
  - Director on Interpol/FATF grey list or RBI watchlist
  - Undisclosed offshore accounts with unexplained fund transfers
  - Active PMLA/FEMA criminal investigation
NEVER veto for weak financials, low DSCR, high D/E ratio, or low credit score.
IMPORTANT: If a value (e.g. CIBIL score "762") appears anywhere in the application
text, it IS provided — do not claim it is missing.

RESPONSE FORMAT (use these exact headers):
MEMO TYPE: INITIAL REVIEW / FLAG / CLEARANCE / VETO
COMPLIANCE STATUS: CLEAR / FLAGGED / VETOED
VETO ISSUED: YES / NO
COMPLIANCE ISSUES:
• [specific issue with regulation reference, or "None"]
DOCUMENTATION REQUIRED: [specific missing documents, or "All satisfactory"]
REGULATORY REFERENCES: [specific regulation citations]"""


MODERATOR_PROMPT = """You are the Moderator at a commercial bank's loan war room.
Compute an accurate RAROC score using the financial metrics provided and deliver the final decision.

RAROC = (Net Interest Income - Expected Loss) / Economic Capital

STEP-BY-STEP (use the FINANCIAL METRICS block — if a metric is missing, use conservative estimate):

1. NII = Loan Amount × 0.11
   IMPORTANT: Use the same unit for all values (Lakhs or Crores — be consistent).

2. PD from DSCR:
   DSCR > 1.50 → PD=0.02 | DSCR 1.25–1.50 → PD=0.05 | DSCR 1.00–1.25 → PD=0.10 | DSCR < 1.00 → PD=0.20 | unknown → PD=0.10
   Add 0.02 to PD only if CIBIL score is explicitly below 700. Do NOT add if CIBIL ≥ 700.

3. LGD from D/E ratio:
   D/E ratio BELOW 1.0 → LGD=0.35  (example: D/E=0.875 → LGD=0.35)
   D/E ratio 1.0 to 2.0 → LGD=0.50
   D/E ratio 2.0 to 3.0 → LGD=0.60
   D/E ratio above 3.0 or no collateral → LGD=0.70
   unknown → LGD=0.55

4. Expected Loss (EL) = PD × LGD × Loan Amount

5. Economic Capital = Loan Amount × risk_weight
   PD ≤ 0.05 AND LGD ≤ 0.45 → risk_weight=0.08
   PD ≤ 0.10 AND LGD ≤ 0.55 → risk_weight=0.12
   PD > 0.10 OR  LGD > 0.55 → risk_weight=0.18
   PD > 0.15 AND LGD > 0.60 → risk_weight=0.25

6. Raw RAROC = (NII - EL) / Economic Capital

7. Adjustments:
   - Unresolved flag penalty: check the UNRESOLVED FLAGS count provided in the context.
     If UNRESOLVED FLAGS count is 0, apply NO penalty.
     If UNRESOLVED FLAGS count > 0, subtract 0.02 per flag.
     Do NOT penalise for flags that compliance has already CLEARED.
   - Add 0.01 if revenue growth > 30% YoY
   - If compliance VETO issued: set RAROC = 0.0

THRESHOLDS: RAROC > 0.15 → APPROVE | 0.08–0.15 → ESCALATE | < 0.08 → REJECT

RESPONSE FORMAT (use these exact headers):
SALES ARGUMENT WEIGHT: [0-10]
RISK ARGUMENT WEIGHT: [0-10]
RAROC CALCULATION:
- NII: [value]
- PD: [value and reason]
- LGD: [value and reason]
- EL: [value]
- Economic Capital: [value]
- Raw RAROC: [value]
- Adjustments: [applied or "None"]
ESTIMATED RAROC: [single decimal e.g. 0.1823]
FINAL RECOMMENDATION: [MUST match your RAROC band exactly:
  RAROC > 0.15  → write APPROVE
  RAROC 0.08-0.15 → write CONDITIONAL
  RAROC < 0.08  → write REJECT
  Compliance veto → write REJECT
DO NOT write APPROVE if RAROC is below 0.15]
KEY DECIDING FACTORS:
• [factor with data]
• [factor with data]
REASONING: [2 sentences with actual metric values]"""


# ─────────────────────────────────────────────
# HELPER: extract financial metrics block
# ─────────────────────────────────────────────

def _extract_financial_metrics(risk_response: str) -> str:
    """Pull the FINANCIAL METRICS EXTRACTED block out of the risk agent's response."""
    if "FINANCIAL METRICS EXTRACTED:" in risk_response.upper():
        parts = re.split(r"FINANCIAL METRICS EXTRACTED:", risk_response, flags=re.IGNORECASE)
        if len(parts) > 1:
            # Take everything up to the next section header
            block = parts[1].strip()
            # Stop at next all-caps header line
            lines = []
            for line in block.split("\n"):
                if re.match(r'^[A-Z][A-Z\s]+:', line) and "DSCR" not in line and "-" not in line[:3]:
                    break
                lines.append(line)
            return "FINANCIAL METRICS:\n" + "\n".join(lines).strip()
    return "FINANCIAL METRICS: Not extracted — use conservative estimates."


# ─────────────────────────────────────────────
# AGENT NODES
# ─────────────────────────────────────────────

def _build_context(
    state: WarRoomState,
    include_sales: bool = False,
    include_risk: bool = False,
    include_metrics: bool = False,
) -> str:
    # Trim loan text to 2500 chars — covers all financial metrics including CIBIL
    loan_text = state['loan_application'][:2500]
    if len(state['loan_application']) > 2500:
        loan_text += "\n[...truncated for brevity...]"

    ctx = (
        f"\nLOAN APPLICATION:\n{loan_text}\n\n"
        f"COMPANY: {state['company_name']}\n"
        f"DEBATE ROUND: {state['debate_round']}\n"
        f"OUTSTANDING FLAGS: {', '.join(state['critical_flags']) if state['critical_flags'] else 'None'}\n"
    )
    if include_metrics and state.get("financial_metrics"):
        ctx += f"\n{state['financial_metrics']}\n"
    if include_sales and state.get("sales_memo"):
        ctx += f"\nSALES MEMO (summary):\n{state['sales_memo'][:600]}\n"
    if include_risk and state.get("risk_memo"):
        ctx += f"\nRISK MEMO (summary):\n{state['risk_memo'][:600]}\n"
    if state.get("debate_history"):
        recent = state["debate_history"][-2:]
        ctx += f"\nRECENT DEBATE:\n{chr(10).join(recent)}\n"
    return ctx


def sales_agent_node(state: WarRoomState) -> dict:
    llm      = get_llm(temperature=0.3)
    context  = _build_context(state, include_risk=True)
    prompt   = f"{SALES_AGENT_PROMPT}\n\n{context}"
    response = _invoke_with_retry(llm, prompt)
    entry    = f"[ROUND {state['debate_round']}] SALES AGENT:\n{response}\n"
    return {"sales_memo": response, "debate_history": [entry]}


def risk_agent_node(state: WarRoomState) -> dict:
    llm      = get_llm(temperature=0.1)   # low temp for factual extraction
    context  = _build_context(state, include_sales=True)
    prompt   = f"{RISK_AGENT_PROMPT}\n\n{context}"
    response = _invoke_with_retry(llm, prompt)

    # Extract structured metrics from risk response
    metrics = _extract_financial_metrics(response)

    # Extract flags
    flags = []
    if "FLAGS RAISED:" in response.upper():
        flag_line = re.split(r"FLAGS RAISED:", response, flags=re.IGNORECASE)[-1].strip().split("\n")[0]
        if flag_line and flag_line.lower().strip() not in ("none", "n/a", ""):
            raw_flags = [f.strip("•- ").strip() for f in re.split(r",|;", flag_line) if f.strip()]
            # Strip markdown bold/italic markers the LLM injects (e.g. "** High Growth")
            flags = [re.sub(r"[*_`]+", "", f).strip() for f in raw_flags
                     if re.sub(r"[*_`]+", "", f).strip()]

    entry     = f"[ROUND {state['debate_round']}] RISK AGENT:\n{response}\n"
    existing  = state.get("critical_flags", [])
    new_flags = list({f for f in existing + flags if f})
    return {
        "risk_memo":         response,
        "financial_metrics": metrics,
        "debate_history":    [entry],
        "critical_flags":    new_flags,
    }


def compliance_agent_node(state: WarRoomState) -> dict:
    llm      = get_llm(temperature=0.1)
    context  = _build_context(state, include_sales=True, include_risk=True)
    prompt   = f"{COMPLIANCE_AGENT_PROMPT}\n\n{context}"
    response = _invoke_with_retry(llm, prompt)
    response_upper = response.upper()

    # Case-insensitive veto detection
    veto = bool(re.search(r"VETO\s+ISSUED\s*:\s*YES", response_upper))

    # Respect sidebar toggle
    if not state.get("veto_enabled", True):
        veto = False

    # Flag resolution — only on explicit CLEAR or CLEARANCE, never on FLAGGED
    resolved = list(state.get("resolved_flags", []))
    compliance_status = ""
    m = re.search(r"COMPLIANCE STATUS\s*:\s*(\w+)", response_upper)
    if m:
        compliance_status = m.group(1).strip()

    COMPLIANCE_KEYWORDS = ["kyc", "aml", "offshore", "pep", "watchlist",
                           "interpol", "grey", "fema", "pmla", "rbi"]
    if compliance_status == "CLEAR":
        for flag in state.get("critical_flags", []):
            if any(kw in flag.lower() for kw in COMPLIANCE_KEYWORDS) and flag not in resolved:
                resolved.append(flag)
    # NOTE: Do NOT clear flags on FLAGGED or VETOED status
    # Partial clearance only on explicit CLEARANCE memo type
    elif compliance_status not in ("FLAGGED", "VETOED"):
        memo_type = ""
        mt = re.search(r"MEMO TYPE\s*:\s*(\w+)", response_upper)
        if mt:
            memo_type = mt.group(1).strip()
        if memo_type == "CLEARANCE":
            for flag in state.get("critical_flags", []):
                if any(kw in flag.lower() for kw in COMPLIANCE_KEYWORDS) and flag not in resolved:
                    resolved.append(flag)

    entry = f"[ROUND {state['debate_round']}] COMPLIANCE AGENT:\n{response}\n"
    return {
        "compliance_memo": response,
        "debate_history":  [entry],
        "compliance_veto": veto,
        "resolved_flags":  resolved,
    }


def moderator_node(state: WarRoomState) -> dict:
    llm = get_llm(temperature=0.1)   # low temp for accurate arithmetic

    capped_history = state["debate_history"][-6:]
    full_debate    = "\n".join(capped_history)
    unresolved     = [f for f in state.get("critical_flags", [])
                      if f not in state.get("resolved_flags", [])]

    context = (
        f"COMPANY: {state['company_name']}\n\n"
        f"{state.get('financial_metrics', 'FINANCIAL METRICS: Not available.')}\n\n"
        f"SALES FINAL POSITION:\n{state.get('sales_memo', 'Not provided')}\n\n"
        f"RISK FINAL POSITION:\n{state.get('risk_memo', 'Not provided')}\n\n"
        f"COMPLIANCE STATUS:\n{state.get('compliance_memo', 'Not provided')}\n\n"
        f"DEBATE HISTORY:\n{full_debate}\n\n"
        f"UNRESOLVED FLAGS COUNT: {len(unresolved)} "
        f"({'None — compliance cleared all flags, apply ZERO penalty' if not unresolved else ', '.join(unresolved)})\n"
        f"COMPLIANCE VETO: "
        f"{'ISSUED — decision must be REJECTED' if state.get('compliance_veto') else 'Not issued'}\n"
    )

    prompt   = f"{MODERATOR_PROMPT}\n\n{context}"
    response = _invoke_with_retry(llm, prompt)

    # ── Parse RAROC — robust extraction ──────────────────────────────────
    raroc = None
    if "ESTIMATED RAROC:" in response.upper():
        try:
            raw_line = re.split(r"ESTIMATED RAROC:", response, flags=re.IGNORECASE)[-1].strip().split("\n")[0]
            # Remove non-numeric except dot and minus
            cleaned = re.sub(r"[^0-9.\-]", " ", raw_line).strip()
            # Take the first number token only (avoids range picking like "0.08-0.15")
            first_num = re.match(r"[\d.]+", cleaned)
            if first_num:
                val = float(first_num.group())
                if val > 1.0:           # LLM returned percent form e.g. 18.23
                    val = val / 100.0
                raroc = round(max(0.0, min(1.0, val)), 4)
        except Exception:
            pass

    if raroc is None:
        print("[MODERATOR] RAROC parse failed — safe-fail 0.0 (REJECT)")
        raroc = 0.0

    # ── Parse agent weights ───────────────────────────────────────────────
    sales_w = 5
    risk_w  = 5
    sm = re.search(r"SALES ARGUMENT WEIGHT\s*:\s*(\d+)", response, re.IGNORECASE)
    rm = re.search(r"RISK ARGUMENT WEIGHT\s*:\s*(\d+)",  response, re.IGNORECASE)
    if sm: sales_w = min(10, max(0, int(sm.group(1))))
    if rm: risk_w  = min(10, max(0, int(rm.group(1))))

    # ── Decision ──────────────────────────────────────────────────────────
    if state.get("compliance_veto"):
        decision = LoanDecision.REJECTED
    elif raroc >= RAROC_APPROVE:
        decision = LoanDecision.APPROVED
    elif raroc >= RAROC_ESCALATE:
        decision = LoanDecision.ESCALATED
    else:
        decision = LoanDecision.REJECTED

    raroc_formula = (
        f"RAROC = (Net Interest Income - Expected Loss) / Economic Capital\n"
        f"Estimated RAROC: {raroc:.4f}\n"
        f"Hurdle Rate:     {RAROC_APPROVE:.4f}\n"
        f"Delta vs hurdle: {raroc - RAROC_APPROVE:+.4f}\n"
        f"Decision band:   "
        f"{'APPROVE (>0.15)' if raroc >= RAROC_APPROVE else 'ESCALATE (0.08–0.15)' if raroc >= RAROC_ESCALATE else 'REJECT (<0.08)'}"
    )

    entry = f"[FINAL] MODERATOR:\n{response}\n"
    return {
        "debate_history":   [entry],
        "raroc_score":      raroc,
        "raroc_formula":    raroc_formula,
        "final_decision":   decision,
        "consensus_rounds": state.get("debate_round", 1),
        "flags_resolved":   len(state.get("resolved_flags", [])),
        "_sales_weight":    sales_w,
        "_risk_weight":     risk_w,
    }


def generate_decision_memo(state: WarRoomState) -> dict:
    llm      = get_llm(temperature=0.2, max_tokens=900)
    decision = str(state["final_decision"]).replace("LoanDecision.", "")
    veto_note = (
        "COMPLIANCE VETO WAS ISSUED — deal blocked regardless of financials."
        if state.get("compliance_veto") else "No compliance veto."
    )
    capped_debate = "\n".join(state["debate_history"][-6:])

    prompt = f"""You are a senior credit officer. Write a concise formal Decision Memo for audit.

COMPANY: {state['company_name']}
FINAL DECISION: {decision}
RAROC: {state.get('raroc_score', 'N/A')}
{veto_note}
FLAGS: {', '.join(state['critical_flags']) if state['critical_flags'] else 'None'}

{state.get('financial_metrics', '')}

DEBATE SUMMARY:
{capped_debate}

CRITICAL INSTRUCTION: The FINAL DECISION is {decision}. Every section of this memo MUST be
consistent with {decision}. Never write REJECT if decision is ESCALATED or APPROVED.
Never write APPROVE if decision is REJECTED. The decision is final and cannot be overridden.

Write the memo with these sections (keep each section to 2-3 sentences):
1. EXECUTIVE SUMMARY (state the {decision} decision clearly in the first sentence)
2. FINANCIAL ASSESSMENT (DSCR, D/E, revenue, collateral — use actual values)
3. COMPLIANCE STATUS
4. RAROC ANALYSIS (explain why {decision} based on RAROC thresholds)
5. FINAL DECISION & RATIONALE (restate {decision} — do not contradict it)
6. CONDITIONS / NEXT STEPS (for ESCALATED: next steps to credit committee; for REJECTED: rejection reasons; for APPROVED: conditions)

Be precise. Reference actual numbers."""

    memo = _invoke_with_retry(llm, prompt)
    return {"decision_memo": str(memo)}


# ─────────────────────────────────────────────
# ROUTING
# ─────────────────────────────────────────────

def should_continue_debate(state: WarRoomState) -> str:
    if state.get("compliance_veto"):
        return "moderator"
    max_rounds = state.get("max_rounds", MAX_DEBATE_ROUNDS)
    if state["debate_round"] >= max_rounds:
        return "moderator"
    unresolved = [
        f for f in state.get("critical_flags", [])
        if f not in state.get("resolved_flags", [])
    ]
    if not unresolved:
        return "moderator"
    # Early exit: if both agents agree on APPROVE, no more debate needed
    sales_pos  = state.get("sales_memo", "").upper()
    risk_pos   = state.get("risk_memo",  "").upper()
    both_approve = (
        "POSITION: APPROVE" in sales_pos
        and ("POSITION: APPROVE" in risk_pos or "POSITION: CONDITIONAL" in risk_pos)
        and not state.get("compliance_veto")
    )
    if both_approve and state["debate_round"] >= 1:
        return "moderator"
    return "continue_debate"


def increment_round(state: WarRoomState) -> dict:
    return {"debate_round": state["debate_round"] + 1}


# ─────────────────────────────────────────────
# GRAPH
# ─────────────────────────────────────────────

def build_war_room_graph() -> StateGraph:
    graph = StateGraph(WarRoomState)

    graph.add_node("sales_agent",      sales_agent_node)
    graph.add_node("risk_agent",       risk_agent_node)
    graph.add_node("compliance_agent", compliance_agent_node)
    graph.add_node("moderator",        moderator_node)
    graph.add_node("generate_memo",    generate_decision_memo)
    graph.add_node("increment_round",  increment_round)

    graph.set_entry_point("sales_agent")

    graph.add_edge("sales_agent",  "risk_agent")
    graph.add_edge("risk_agent",   "compliance_agent")

    graph.add_conditional_edges(
        "compliance_agent",
        should_continue_debate,
        {"continue_debate": "increment_round", "moderator": "moderator"},
    )

    graph.add_edge("increment_round", "sales_agent")
    graph.add_edge("moderator",       "generate_memo")
    graph.add_edge("generate_memo",   END)

    return graph.compile()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

def run_war_room(
    loan_text:    str,
    company_name: str,
    max_rounds:   int  = MAX_DEBATE_ROUNDS,
    veto_enabled: bool = True,
) -> WarRoomState:
    if not os.environ.get("GROQ_API_KEY", "").strip():
        raise ValueError("GROQ_API_KEY is not set. Please enter your Groq API key in the sidebar.")

    _llm_cache.clear()

    graph = build_war_room_graph()

    initial_state: WarRoomState = {
        "loan_application":  loan_text,
        "company_name":      company_name,
        "sales_memo":        "",
        "risk_memo":         "",
        "compliance_memo":   "",
        "financial_metrics": "",
        "debate_history":    [],
        "debate_round":      1,
        "max_rounds":        max_rounds,
        "veto_enabled":      veto_enabled,
        "compliance_veto":   False,
        "critical_flags":    [],
        "resolved_flags":    [],
        "raroc_score":       None,
        "raroc_formula":     "",
        "final_decision":    LoanDecision.PENDING,
        "decision_memo":     "",
        "consensus_rounds":  0,
        "flags_resolved":    0,
        "_sales_weight":     5,
        "_risk_weight":      5,
    }

    final_state = graph.invoke(initial_state)
    final_state["company_name"] = company_name
    return final_state